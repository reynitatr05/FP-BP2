package com.example.petshop


import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard)

        //mendapatkan layout/tampilan button atau tombol navigasi
        val btn_makanan:LinearLayout = findViewById(R.id.btn_makanan)
        val btn_perawatan:LinearLayout = findViewById(R.id.btn_perawatan)
        val btn_aksesoris:LinearLayout = findViewById(R.id.btn_aksesoris)
        val btn_perlengkapan:LinearLayout = findViewById(R.id.btn_perlengkapan)
        val btn_logout:LinearLayout = findViewById(R.id.btn_logout)

        //pindah ke halaman makanan
        btn_makanan.setOnClickListener {
            val pindah = Intent(this, Makanan::class.java)
            startActivity(pindah)
        }

//        //pindah ke halaman perlengkapan
        btn_perawatan.setOnClickListener {
            val pindah = Intent(this, Perawatan::class.java)
            startActivity(pindah)
        }
//
        //pindah ke halaman aksesoris
        btn_aksesoris.setOnClickListener {
            val pindah = Intent(this, Aksesoris::class.java)
            startActivity(pindah)
        }
//
        //pindah ke halaman perlengkapan
        btn_perlengkapan.setOnClickListener {
            val pindah = Intent(this, Perlengkapan::class.java)
            startActivity(pindah)
        }

        //LOGOUT
        val tiket: SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
        btn_logout.setOnClickListener {
            //hapustiket
            val edittiket = tiket.edit()
            edittiket.clear()
            edittiket.commit()

            //pindah halaman ke login agar tidak bisa diback ke mahasiswa
            val keluar:Intent = Intent(this, Login::class.java)
            startActivity(keluar)
            finish()
        }
    }
}