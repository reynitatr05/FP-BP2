package com.example.petshop

import android.annotation.SuppressLint
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream

class Aksesoris : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.aksesoris)

        val rv_aksesoris: RecyclerView = findViewById(R.id.rv_aksesoris)

        val id: MutableList<String> = mutableListOf()
        val nama: MutableList<String> = mutableListOf()
        val harga: MutableList<String> = mutableListOf()
        val foto: MutableList<Int> = mutableListOf()

        val dbpetshop: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)
        val tampilproduk = dbpetshop.rawQuery("SELECT * FROM Aksesoris", null)

        while (tampilproduk.moveToNext())
        {
            try {
                val bis = ByteArrayInputStream(tampilproduk.getBlob(3))
                val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
                foto.add(R.drawable.noimage) // Simpan resource ID gambar default
            } catch (eek: Exception) {
                foto.add(R.drawable.noimage) // Simpan resource ID gambar default jika terjadi kesalahan
            }
            id.add(tampilproduk.getString(0))
            nama.add(tampilproduk.getString(1))
            harga.add(tampilproduk.getString(2))

        }

        val pik: Aksesoris_Item = Aksesoris_Item(this, id, nama, harga, foto )
        rv_aksesoris.adapter = pik
        rv_aksesoris.layoutManager = LinearLayoutManager(this)


        val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah = Intent(this, Dashboard::class.java)
            startActivity(pindah)
        }

        val btn_tambah: LinearLayout = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah = Intent(this, Aksesoris_Tambah::class.java)
            startActivity(pindah)
        }
    }
}