package com.example.petshop

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream

class Makanan : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.makanan)

        val rv_kaos: RecyclerView = findViewById(R.id.rv_kaos)

        val id: MutableList<String> = mutableListOf()
        val nama: MutableList<String> = mutableListOf()
        val harga: MutableList<String> = mutableListOf()
        val foto: MutableList<Bitmap> = mutableListOf()

        val dbpetshop: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)
        val tampilproduk = dbpetshop.rawQuery("SELECT * FROM Makanan", null)

        while (tampilproduk.moveToNext())
        {
            try {
                    val bis = ByteArrayInputStream(tampilproduk.getBlob(3))
                  val  gambarbitmap:Bitmap = BitmapFactory.decodeStream(bis)
                foto.add(gambarbitmap)
                } catch (eek:Exception) {
                    val gambarbitmap : Bitmap = BitmapFactory.decodeResource(this.resources, R.drawable.noimage)
                    foto.add(gambarbitmap)
                }
                id.add(tampilproduk.getString(0))
                nama.add(tampilproduk.getString(1))
                harga.add(tampilproduk.getString(2))

            }

            val pik: Makanan_Item = Makanan_Item(this, id, nama, harga, foto)
            rv_kaos.adapter = pik
            rv_kaos.layoutManager = LinearLayoutManager(this)


            val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
            btn_kembali.setOnClickListener {
                val pindah = Intent(this, Dashboard::class.java)
                startActivity(pindah)
            }

            val btn_tambah: LinearLayout = findViewById(R.id.btn_tambah)
            btn_tambah.setOnClickListener {
                val pindah = Intent(this, Makanan_Tambah::class.java)
                startActivity(pindah)
            }
        }
    }
