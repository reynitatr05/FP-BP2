package com.example.petshop

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Perawatan_Hapus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perawatan_hapus)

        val id_perawatan_terpilih:String = intent.getStringExtra("id_perawatan_terpilih").toString()

        val dbpetshop: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)
        val query = dbpetshop.rawQuery("delete from Perawatan where perawatan_id='$id_perawatan_terpilih'", null)
        query.moveToNext()

        val pindah: Intent = Intent(this, Perawatan::class.java)
        startActivity(pindah)
    }
}