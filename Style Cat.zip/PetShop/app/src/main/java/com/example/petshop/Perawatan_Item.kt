package com.example.petshop

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Perawatan_Item(
    val context: Context,
    val id: MutableList<String>,
    val nama: MutableList<String>,
    val harga: MutableList<String>,
    val foto: MutableList<Int>
) : RecyclerView.Adapter<Perawatan_Item.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.perawatan_item, parent, false)
        return ViewHolder(view)
    }

    class ViewHolder (ItemView: View) : RecyclerView.ViewHolder(ItemView){
        val txt_nama: TextView = itemView.findViewById(R.id.txt_nama)
        val txt_harga: TextView = itemView.findViewById(R.id.txt_harga)
        val iv_foto: ImageView = ItemView.findViewById(R.id.iv_foto)
        val btn_edit: TextView = ItemView.findViewById(R.id.btn_edit)
        val btn_hapus: TextView = ItemView.findViewById(R.id.btn_hapus)

    }

    override fun getItemCount(): Int {
        return nama.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txt_nama.text=nama.get(position)
        holder.txt_harga.text=harga.get(position)
        holder.iv_foto.setImageResource(foto.get(position))

        holder.btn_edit.setOnClickListener {
            val id_perawatan_terpilih:String = id.get(position)

            val pindah: Intent = Intent(context, Perawatan_Ubah::class.java)
            pindah.putExtra("id_perawatan_terpilih", id_perawatan_terpilih)
            context.startActivity(pindah)
        }

        holder.btn_hapus.setOnClickListener {
            val id_perawatan_terpilih:String = id.get(position)

            val pindah: Intent = Intent(context, Perawatan_Hapus::class.java)
            pindah.putExtra("id_perawatan_terpilih", id_perawatan_terpilih)
            context.startActivity(pindah)
        }


    }

}