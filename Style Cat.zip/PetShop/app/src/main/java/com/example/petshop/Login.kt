package com.example.petshop

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import com.example.petshop.Dashboard
import com.example.petshop.R

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        val txt_email: EditText = findViewById(R.id.txt_email)
        val txt_password: EditText = findViewById(R.id.txt_password)
        val btn_login: LinearLayout = findViewById(R.id.btn_login)

        btn_login.setOnClickListener {
            val isi_email: String = txt_email.text.toString()
            val isi_password: String = txt_password.text.toString()

            val dbthrift: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)

            val query = dbthrift.rawQuery("SELECT * FROM admin WHERE admin_email='$isi_email' AND admin_password='$isi_password'", null)
            val cek = query.moveToNext()

            if (cek) {
                val id = query.getString(0)
                val email = query.getString(1)
                val password = query.getString(2)

                val session: SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
                val masuk = session.edit()
                masuk.putString("admin_id", id)
                masuk.putString("admin_email", email)
                masuk.putString("admin_password", password)
                masuk.apply()

                val pindah: Intent

                // Check if the user is admin or user
                if (email == "admin@gmail.com" && password == "admin") {
                    pindah = Intent(this, Dashboard::class.java)
                } else if (email == "user@gmail.com" && password == "user") {
                    pindah = Intent(this, User::class.java)
                } else {
                    Toast.makeText(this, "Email atau Password anda Salah DULLL!!!!", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }

                startActivity(pindah)
                finish()
            } else {
                Toast.makeText(this, "Email atau Password anda Salah DULLL!!!!", Toast.LENGTH_LONG).show()
            }
        }
    }
}
