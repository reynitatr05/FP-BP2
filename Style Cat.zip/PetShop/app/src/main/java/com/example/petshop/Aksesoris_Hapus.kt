package com.example.petshop

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Aksesoris_Hapus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aksesoris_hapus)

        val id_aksesoris_terpilih:String = intent.getStringExtra("id_aksesoris_terpilih").toString()

        val dbpetshop: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)
        val query = dbpetshop.rawQuery("delete from Aksesoris where aksesoris_id='$id_aksesoris_terpilih'", null)
        query.moveToNext()

        val pindah: Intent = Intent(this, Aksesoris::class.java)
        startActivity(pindah)

    }
}