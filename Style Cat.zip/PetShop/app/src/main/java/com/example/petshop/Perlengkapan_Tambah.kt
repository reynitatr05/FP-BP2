package com.example.petshop

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts

class Perlengkapan_Tambah : AppCompatActivity() {
    var urlgambar: Uri? = null
    var bitmapgambar: Bitmap? = null
    var iv_upload: ImageView? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perlengkapan_tambah)

        val txt_nama: EditText = findViewById(R.id.txt_namaproduk)
        val txt_harga: EditText = findViewById(R.id.txt_harga)
        val btn_simpan: LinearLayout = findViewById(R.id.btn_tambah)

        btn_simpan.setOnClickListener {
            val isi_nama: String = txt_nama.text.toString()
            val isi_harga: String = txt_harga.text.toString()

            val dbpetshop: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)
            val eksekutor = dbpetshop.rawQuery(
                "INSERT INTO Perlengkapan(perlengkapan_nama, perlengkapan_harga) VALUES('$isi_nama','$isi_harga')",
                null
            )
            eksekutor.moveToNext()

            val pindah: Intent = Intent(this, Perlengkapan::class.java)
            startActivity(pindah)
        }

        val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah = Intent(this, Perlengkapan::class.java)
            startActivity(pindah)
        }
    }

    val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) {
            val gambardiperoleh = it.data

            if (gambardiperoleh != null) {
                urlgambar = gambardiperoleh.data

                bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver, urlgambar)
                iv_upload?.setImageBitmap(bitmapgambar)
            }
        }
    }
}