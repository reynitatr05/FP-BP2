package com.example.petshop

import android.annotation.SuppressLint
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class Perawatan_Ubah : AppCompatActivity() {
    var iv_upload: ImageView? = null
    var urlgambar: Uri? = null
    var bitmapgambar: Bitmap? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perawatan_ubah)

        val id_perawatan_terpilih: String =
            intent.getStringExtra("id_perawatan_terpilih").toString()

        val dbpetshop: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)
        val ambil = dbpetshop.rawQuery(
            "select * from Perawatan where perawatan_id='$id_perawatan_terpilih'",
            null
        )
        ambil.moveToNext()
        var iv_upload: ImageView = findViewById(R.id.iv_upload)
        val isi_nama: String = ambil.getString(1)
        val isi_harga: String = ambil.getString(2)
        val isi_foto: ByteArray = ambil.getBlob(3)

        val txt_nama: EditText = findViewById(R.id.txt_namaproduk)
        val txt_harga: EditText = findViewById(R.id.txt_harga)
        val btn_simpan: LinearLayout = findViewById(R.id.btn_edit)
        iv_upload = findViewById(R.id.iv_upload)

        txt_nama.setText(isi_nama)
        txt_harga.setText(isi_harga)

        try {
            val bis = ByteArrayInputStream(isi_foto)
            val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
            iv_upload?.setImageBitmap(gambarbitmap)
        } catch (eek: Exception) {
            val gambarbitmap: Bitmap =
                BitmapFactory.decodeResource(this.resources, R.drawable.noimage)
            iv_upload?.setImageBitmap(gambarbitmap)
        }
        try {
            val bis = ByteArrayInputStream(isi_foto)
            val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
            iv_upload?.setImageBitmap(gambarbitmap)
        } catch (eek: Exception) {
            val gambarbitmap: Bitmap =
                BitmapFactory.decodeResource(this.resources, R.drawable.noimage)
            iv_upload?.setImageBitmap(gambarbitmap)
        }
        btn_simpan.setOnClickListener {
            val nama_baru: String = txt_nama.text.toString()
            val harga_baru: String = txt_harga.text.toString()

            val bos = ByteArrayOutputStream()
            bitmapgambar?.compress(Bitmap.CompressFormat.JPEG, 100, bos)
            val bytearraygambar = bos.toByteArray()

            //val ngubah = dbpetshop.rawQuery("UPDATE Makanan SET makanan_nama = '$nama_baru', makanan_harga = '$harga_baru' where makanan_id = '$id_makanan_terpilih'", null)
            //ngubah.moveToNext()
            val sql =
                "UPDATE Perawatan SET perawatan_nama=?, perawatan_harga=?, perawatan_foto=? WHERE id_perawatan='$id_perawatan_terpilih' "
            val statement = dbpetshop.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1, isi_nama)
            statement.bindString(2, isi_harga)
            statement.bindBlob(3, bytearraygambar)
            statement.executeUpdateDelete()

            val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
            btn_kembali.setOnClickListener {
                val pindah = Intent(this, Perawatan::class.java)
                startActivity(pindah)
            }
        }
    }
}