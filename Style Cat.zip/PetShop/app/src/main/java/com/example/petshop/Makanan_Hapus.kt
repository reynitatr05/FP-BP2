package com.example.petshop

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Makanan_Hapus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.makanan_hapus)

        val id_makanan_terpilih:String = intent.getStringExtra("id_makanan_terpilih").toString()

        val dbpetshop: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)
        val query = dbpetshop.rawQuery("delete from Makanan where makanan_id='$id_makanan_terpilih'", null)
        query.moveToNext()

        val pindah: Intent = Intent(this, Makanan::class.java)
        startActivity(pindah)
    }
}