package com.example.petshop

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayInputStream

class Perlengkapan_Ubah : AppCompatActivity() {
    var iv_upload: ImageView? = null
    var urlgambar: Uri? = null
    var bitmapgambar: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perlengkapan_ubah)

        val id_perlengkapan_terpilih: String =
            intent.getStringExtra("id_perlengkapan_terpilih").toString()

        val dbpetshop: SQLiteDatabase = openOrCreateDatabase("petshop", MODE_PRIVATE, null)
        val ambil = dbpetshop.rawQuery(
            "select * from Perlengkapan where perlengkapan_id='$id_perlengkapan_terpilih'",
            null
        )
        ambil.moveToNext()

        var iv_upload: ImageView = findViewById(R.id.iv_upload)
        val isi_nama: String = ambil.getString(1)
        val isi_harga: String = ambil.getString(2)
        val isi_foto: ByteArray = ambil.getBlob(3)

        val txt_nama: EditText = findViewById(R.id.txt_namaproduk)
        val txt_harga: EditText = findViewById(R.id.txt_harga)
        val btn_simpan: LinearLayout = findViewById(R.id.btn_edit)
        iv_upload = findViewById(R.id.iv_upload)

        txt_nama.setText(isi_nama)
        txt_harga.setText(isi_harga)

        try {
            val bis = ByteArrayInputStream(isi_foto)
            val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
            iv_upload?.setImageBitmap(gambarbitmap)
        } catch (eek: Exception) {
            val gambarbitmap: Bitmap =
                BitmapFactory.decodeResource(this.resources, R.drawable.noimage)
            iv_upload?.setImageBitmap(gambarbitmap)
        }

        btn_simpan.setOnClickListener {
            val nama_baru: String = txt_nama.text.toString()
            val harga_baru: String = txt_harga.text.toString()

            val ngubah = dbpetshop.rawQuery(
                "UPDATE Perlengkapan SET perlengkapan_nama = '$nama_baru', perlengkapan_harga = '$harga_baru' where perlengkapan_id = '$id_perlengkapan_terpilih'",
                null
            )
            ngubah.moveToNext()

            val pindah: Intent = Intent(this, Perlengkapan::class.java)
            startActivity(pindah)
        }

        val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah = Intent(this, Perlengkapan::class.java)
            startActivity(pindah)
        }
    }

    val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) {
            val gambardiperoleh = it.data

            if (gambardiperoleh != null) {
                urlgambar = gambardiperoleh.data

                bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver, urlgambar)
                iv_upload?.setImageBitmap(bitmapgambar)
            }
        }
    }
}